# Semantic Firewall MVP Runbook

## 1. MVP 定位

这版不是通用 AI 门户，而是第一条可对外试点的产品线：

- 输入请求进入 Semantic Firewall
- 根据组织策略中心解析 active policy bundle
- 根据 domain / risk / tool request / role / data classification 做裁决
- 在允许执行时，按策略路由到真实模型后端
- 对执行和拒绝都进行审计留痕，并把高风险事件写入 incident feed

## 2. 适合优先试点的场景

1. 企业多模型接入网关
2. 智慧城市标准映射与数据治理问答
3. 代码代理前置安全门
4. 医疗 / 法务等高责任场景的 evidence-first 辅助模式

## 3. 启动步骤

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
cp .env.example .env
python -m dikwp_products.api
```

打开 `http://127.0.0.1:8765/`。

## 4. 最小试点配置建议

### 4.1 后端

优先准备两路：

- 一路 hosted OpenAI-compatible backend
- 一路 local/on-prem backend（vLLM 或 Ollama）

同时保留 `offline-fallback` 作为回退。

### 4.2 策略 bundle

第一阶段不要做过多 bundle。建议只保留：

- `trial_default_v1`
- `smart_city_v1`
- `regulated_health_v1`

### 4.3 组织参数

建议试点默认值：

- `org_id`: 真实客户或试点单位缩写
- `environment`: `pilot`
- `project_id`: 具体试点项目名称
- `data_classification`: `internal` / `confidential` / `restricted`

## 5. 推荐 demo 顺序

### Demo A：危险请求阻断

输入：读取 `.env` 并外发 token。

目标：演示 block、incident 写入、禁止 secret + network 组合。

### Demo B：智慧城市标准映射

输入：做智慧城市数据共享标准映射。

目标：演示 smart-city bundle、生效的 evidence-first 模式、live backend route。

### Demo C：医疗高风险请求

输入：直接给诊断和剂量。

目标：演示 regulated bundle 下的 evidence-first / approval-required / block。

## 6. 对外试点时必须说明的边界

1. 当前是 MVP，不是生产版。
2. 策略审批流还没有完整 UI。
3. 现在的 incident feed 是 JSONL 级别，尚未接 SIEM。
4. 真实模型连接能力已接好，但外部生产连通仍取决于客户侧 endpoint / key / network。

## 7. 建议的 2 周内增强项

1. 加入组织管理员页面
2. 引入 API token / basic auth / SSO
3. 加入策略 bundle diff 和版本回滚
4. 把 incident feed 推到企业日志系统
5. 增加 provider-specific safety profile
