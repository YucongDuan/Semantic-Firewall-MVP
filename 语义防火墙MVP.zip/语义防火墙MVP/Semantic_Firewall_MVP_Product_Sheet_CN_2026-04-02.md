# Semantic Firewall MVP Product Sheet

## 一句话定位

面向可控大模型 / 可信智能体的**语义控制网关**：在请求真正进入模型之前，先进行语义解析、组织策略裁决、后端路由和审计留痕。

## 核心能力

1. **DIKWP semantic packet**
   - 把输入编译成 D / I / K / W / P 语义包
2. **Risk classification**
   - 识别 prompt injection、secret exfiltration、network exfiltration、destructive action、高风险医疗/法务等模式
3. **Organization policy center**
   - 按组织和环境激活 policy bundle
   - 解析 profile、role、domain、backend policy
4. **Live backend routing**
   - 根据 policy 选择 OpenAI-compatible / vLLM / Ollama / offline fallback
5. **Audit / incident feed**
   - 对决策和执行都做留痕
   - 高风险事件进入 incident feed

## MVP 适合卖什么

- 多模型入口安全网关试点
- 智慧城市 / 标准映射问答网关
- 代码代理上生产前的前置控制层
- 高责任行业中的 evidence-first AI assistant

## 与专利模块的映射

- DIKW / DIKWP typed resource / graph / intention inference：用于 semantic packet 和 policy-aware reasoning
- 内容合规与不合规请求分解：用于 allow / guarded / evidence-first / approval-required / block
- 软件系统生命周期评估与授权：用于 role、approval、audit、whitebox export

## MVP 当前不包含

- 企业级审批流 UI
- 多租户隔离
- 真正的 IAM / SSO
- 生产级日志汇聚与告警
- 完整的模型输出后处理与脱敏编排
